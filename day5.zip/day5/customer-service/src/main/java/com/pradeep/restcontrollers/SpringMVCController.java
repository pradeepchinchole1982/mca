package com.pradeep.restcontrollers;

import java.util.Date;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/pradeep")
@RestController
public class SpringMVCController {

	
	public SpringMVCController() {
	System.out.println("===========SpringController created=============");
	}
	
	
	@GetMapping("/today")
	public String getToday() {
		return "REST DispatcherServelt : Today is "+new Date();
	}
	
	@PostMapping("/today")
	public String postToday() {
		return "REST DispatcherServelt : Today is "+new Date();
	}
	
	
	@DeleteMapping("/today")
	public String deleteToday() {
		return "REST DispatcherServelt : Today is "+new Date();
	}
	
	
	@PutMapping("/today")
	public String putToday() {
		return "REST DispatcherServelt : Today is "+new Date();
	}
	
	
	@PatchMapping("/today")
	public String patchToday() {
		return "REST DispatcherServelt : Today is "+new Date();
	}
	
	
}
