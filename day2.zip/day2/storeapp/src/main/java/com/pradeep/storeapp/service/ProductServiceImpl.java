package com.pradeep.storeapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pradeep.storeapp.dao.IProductDao;
import com.pradeep.storeapp.domain.Product;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductDao productDao;

	@Override
	public void addProduct(Product product) {
		productDao.save(product);

	}

	@Override
	public void updateProduct(Product product) {
		productDao.save(product);

	}

	@Override
	public void deleteProduct(int productId) {
		productDao.deleteById(productId);

	}

	@Override
	public Product findProductById(int productId) {
		return productDao.findById(productId).get();
	}

	@Override
	public List<Product> findAllProducts() {
		return productDao.findAll();
	}

}
