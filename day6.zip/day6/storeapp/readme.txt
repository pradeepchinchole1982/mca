create a jar file using command : mvn clean package install 

To build image 
-----------------
docker build -t pradeepch82/storeapp:1.1 .


To login to docker hub
-----------------------
docker login
username :pradeepch82
password :Sony@1989

To push image to docker hub
-----------------------------
docker push pradeepch82/storeapp:1.1

To create 
docker run --name storeapp -p   1111:8080 pradeepch82/storeapp:1.1




  