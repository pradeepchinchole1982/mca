package com.pradeep.storeapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.pradeep.storeapp.dao.IProductDao;
import com.pradeep.storeapp.domain.Product;

@SpringBootApplication
public class StoreappApplication implements CommandLineRunner {

	@Autowired
	IProductDao productDao;

	public static void main(String[] args) {
		SpringApplication.run(StoreappApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println(".......Executing the script....");
		productDao.save(new Product(null, "LG", 1000.00, "mobile", "LG"));
		productDao.save(new Product(null, "SAMSUNG", 1000.00, "mobile", "SAMSUNG"));
		productDao.save(new Product(null, "ONIDA", 1000.00, "mobile", "ONIDA"));

	}

}
