Admin Server      :8086
StoreApp          :8080
EurekaServer      :8761

  