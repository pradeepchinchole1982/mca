package com.pradeep.storeapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.storeapp.domain.Product;
import com.pradeep.storeapp.service.IProductService;

@RequestMapping("/products")
@RestController
public class ProductRestController {

	@Autowired
	private IProductService productService;

	@GetMapping
	public List<Product> findAllProducts() {
		return productService.findAllProducts();
	}

	@GetMapping("/{productId}")
	public Product findProduct(@PathVariable("productId") int productId) {
		return productService.findProductById(productId);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@DeleteMapping("/{productId}")
	public void deleteProduct(@PathVariable("productId") int productId) {
		productService.deleteProduct(productId);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@PutMapping
	public void updateProduct(@RequestBody Product product) {
		productService.updateProduct(product);
	}

	@ResponseStatus(value = HttpStatus.CREATED)
	@PostMapping
	public void addProduct(@RequestBody Product product) {
		productService.addProduct(product);
	}

}
