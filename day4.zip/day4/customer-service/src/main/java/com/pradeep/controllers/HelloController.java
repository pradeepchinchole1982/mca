package com.pradeep.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.DispatcherServlet;

@Controller
public class HelloController {

	public HelloController() {
	System.out.println("Hello Controller Created");
	}
	
	
	@RequestMapping(value = "/hello",method = RequestMethod.GET)
	public String helloAll() {
		return "hello";    //   /WEB-INF/views/hello.jsp
	}
	
	
}
